"use client";

import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

/** Consistent page content container for every section of the site. */
export function Container({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8", className)}>{children}</div>;
}
